package org.tron.core.exception;

public class CancelException extends TronException {

  public CancelException() {
    super();
  }

  public CancelException(String message) {
    super(message);
  }

}
