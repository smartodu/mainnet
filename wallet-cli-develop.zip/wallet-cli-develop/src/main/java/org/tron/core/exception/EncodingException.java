package org.tron.core.exception;

public class EncodingException extends TronException {
  public EncodingException() {
    super();
  }

  public EncodingException(String msg) {
    super(msg);
  }
}
